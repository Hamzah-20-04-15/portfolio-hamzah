# -*- coding: utf-8 -*-
"""
@author Maryam Khan Jadoon
@author: M.Hamzah Iqbal
"""

import pandas as pd  # for data handling
import os            # for file system operations
import matplotlib.pyplot as plt  # for plotting charts

# Parent class for basic student information
class PersonData:
    def __init__(self, student_name, student_age):
        self.student_name = student_name
        self.student_age = student_age

# Child class that extends PersonData with academic details
class AcademicRecord(PersonData):
    def __init__(self, student_name, student_age, student_id, program, gender):
        super().__init__(student_name, student_age)
        self.student_id = student_id
        self.program = program
        self.gender = gender

# Main system to manage academic records
class RecordSystem:
    DATA_FILE = "academic_data.csv"  # file to store data

    def __init__(self):
        self.records = self.load_records()  # load data on start

    # Load records from CSV if available
    def load_records(self):
        if os.path.exists(self.DATA_FILE):
            df = pd.read_csv(self.DATA_FILE, dtype=str)
            df.columns = df.columns.str.upper()  # ensure column names are uppercase
            return df.fillna("")  # replace NaN with empty strings
        # Return an empty DataFrame with required columns if file doesn't exist
        return pd.DataFrame(columns=['STUDENT_NAME', 'STUDENT_AGE', 'STUDENT_ID', 'PROGRAM', 'GENDER'])

    # Save records to CSV
    def save_records(self):
        self.records.to_csv(self.DATA_FILE, index=False)

    # Add new student record
    def add_new_record(self):
        print("\nAdd New Academic Record")
        name = input("Student Name: ").title()
        age = input("Student Age: ")
        sid = input("Student ID: ").upper()
        program = input("Academic Program: ").upper()
        gender = input("Gender (Male/Female): ").capitalize()

        # Prevent duplicate IDs
        if sid in self.records['STUDENT_ID'].values:
            print("Error: Student ID already exists!")
            return

        # Create a new record and append to DataFrame
        new_data = pd.DataFrame([[name, age, sid, program, gender]],
                                columns=['STUDENT_NAME', 'STUDENT_AGE', 'STUDENT_ID', 'PROGRAM', 'GENDER'])
        self.records = pd.concat([self.records, new_data], ignore_index=True)
        self.save_records()
        print("Record added successfully!")

    # Display all student records
    def display_records(self):
        print("\n--- Academic Records ---")
        if self.records.empty:
            print("No records available")
            return

        # Format display: title case for names, uppercase for programs
        display_df = self.records.copy()
        display_df['STUDENT_NAME'] = display_df['STUDENT_NAME'].str.title()
        display_df['PROGRAM'] = display_df['PROGRAM'].str.upper()
        print(display_df.to_string(index=False))

    # Search for a record using Student ID
    def find_record(self):
        search_id = input("Enter Student ID to search: ").upper()
        result = self.records[self.records['STUDENT_ID'] == search_id]

        if not result.empty:
            print("\nFound Record:")
            print(result.to_string(index=False))
        else:
            print("No matching record found")

    # Update a student record by ID
    def update_record(self):
        sid = input("Enter Student ID to update: ").upper()
        if sid not in self.records['STUDENT_ID'].values:
            print("Student not found")
            return

        print("\nLeave blank to keep current value")
        current = self.records[self.records['STUDENT_ID'] == sid].iloc[0]

        # Ask for new values, keep old if blank
        name = input(f"New name [{current['STUDENT_NAME']}]: ") or current['STUDENT_NAME']
        age = input(f"New age [{current['STUDENT_AGE']}]: ") or current['STUDENT_AGE']
        program = input(f"New program [{current['PROGRAM']}]: ") or current['PROGRAM']
        gender = input(f"New gender [{current['GENDER']}]: ") or current['GENDER']

        # Update the record
        self.records.loc[self.records['STUDENT_ID'] == sid] = [
            name.title(), age, sid, program.upper(), gender.capitalize()
        ]
        self.save_records()
        print("Record updated successfully!")

    # Remove a student record
    def remove_record(self):
        sid = input("Enter Student ID to remove: ").upper()
        if sid not in self.records['STUDENT_ID'].values:
            print("Student not found")
            return

        # Filter out the record to be deleted
        self.records = self.records[self.records['STUDENT_ID'] != sid]
        self.save_records()
        print("Record removed successfully!")
        self.display_records()

    # Sort records based on a selected field
    def sort_records(self):
        print("\nSort by:")
        print("1. Student Name")
        print("2. Student ID")
        print("3. Academic Program")
        choice = input("Enter choice (1-3): ")

        if choice == '1':
            self.records.sort_values('STUDENT_NAME', inplace=True)
        elif choice == '2':
            self.records.sort_values('STUDENT_ID', inplace=True)
        elif choice == '3':
            self.records.sort_values('PROGRAM', inplace=True)
        else:
            print("Invalid choice")
            return

        self.save_records()
        print("Records sorted successfully!")
        self.display_records()

    # Plot pie chart of male vs female students
    def plot_gender_distribution(self):
        print("\n--- Gender Distribution ---")
        if self.records.empty or 'GENDER' not in self.records.columns:
            print("No records or GENDER column missing")
            return

        gender_counts = self.records['GENDER'].str.capitalize().value_counts()

        if gender_counts.empty:
            print("No gender data available.")
            return

        labels = gender_counts.index
        sizes = gender_counts.values
        colors = ['skyblue', 'lightpink']  # Color for male/female

        # Plotting pie chart
        plt.figure(figsize=(6, 6))
        plt.pie(sizes, labels=labels, autopct='%1.1f%%', colors=colors, startangle=140)
        plt.title("Male vs Female Student Distribution", pad=20)
        plt.axis('equal')  # Make the pie chart a circle
        plt.show()

    # Open the CSV file using default program (like Excel)
    def open_csv_file(self):
        if os.path.exists(self.DATA_FILE):
            print("Opening CSV file...")
            os.startfile(self.DATA_FILE)
        else:
            print("No CSV file found to open.")

# Menu function to interact with user
def show_menu():
    system = RecordSystem()

    while True:
        print("\n==== Academic Record System ====")
        print("1. Add New Record")
        print("2. View All Records")
        print("3. Search Record")
        print("4. Update Record")
        print("5. Delete Record")
        print("6. Sort Records")
        print("7. Exit System")
        print("8. View Gender Distribution Chart")
        print("9. Open CSV File")

        option = input("Select option (1-9): ")

        if option == '1':
            system.add_new_record()
        elif option == '2':
            system.display_records()
        elif option == '3':
            system.find_record()
        elif option == '4':
            system.update_record()
        elif option == '5':
            system.remove_record()
        elif option == '6':
            system.sort_records()
        elif option == '7':
            print("Thank you for using this system.")
            break
        elif option == '8':
            system.plot_gender_distribution()
        elif option == '9':
            system.open_csv_file()
        else:
            print("Invalid option, please try again.")

# Start the program
show_menu()
